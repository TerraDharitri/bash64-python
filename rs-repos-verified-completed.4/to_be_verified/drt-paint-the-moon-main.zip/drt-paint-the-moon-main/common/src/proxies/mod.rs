mod paint_harvest_proxy;
mod paint_the_moon_proxy;

pub use paint_harvest_proxy::PaintHarvestScProxy;
pub use paint_the_moon_proxy::PaintTheMoonScProxy;
