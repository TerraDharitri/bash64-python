mod data;
mod routes;

pub use data::Config;
pub use routes::*;
