fn main() {
    dharitri_sc_meta_lib::cli_main::<paint_harvest_sc::AbiProvider>();
}
