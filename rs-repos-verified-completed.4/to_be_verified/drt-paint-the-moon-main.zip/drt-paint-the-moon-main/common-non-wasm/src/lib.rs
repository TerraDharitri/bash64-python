mod config;
mod query;

pub use config::ConfigNonWasm;
pub use query::{PointsNonWasm, QueryResponseNonWasm};
