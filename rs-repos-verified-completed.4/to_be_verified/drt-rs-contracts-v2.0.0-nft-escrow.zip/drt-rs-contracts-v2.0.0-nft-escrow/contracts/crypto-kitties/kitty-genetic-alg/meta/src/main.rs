fn main() {
    dharitri_sc_meta::cli_main::<kitty_genetic_alg::AbiProvider>();
}
