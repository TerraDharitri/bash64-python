fn main() {
    dharitri_sc_meta::cli_main::<order_book_pair::AbiProvider>();
}
