fn main() {
    dharitri_sc_meta::cli_main::<proxy_pause::AbiProvider>();
}
