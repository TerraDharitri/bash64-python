fn main() {
    dharitri_sc_meta::cli_main::<dharitri_wrewa_swap_sc::AbiProvider>();
}
