fn main() {
    dharitri_sc_meta::cli_main::<mystery_box::AbiProvider>();
}
