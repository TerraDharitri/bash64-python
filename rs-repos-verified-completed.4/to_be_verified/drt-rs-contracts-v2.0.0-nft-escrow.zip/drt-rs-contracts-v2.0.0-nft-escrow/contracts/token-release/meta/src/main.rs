fn main() {
    dharitri_sc_meta::cli_main::<token_release::AbiProvider>();
}
