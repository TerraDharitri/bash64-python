fn main() {
    dharitri_sc_meta::cli_main::<bonding_curve_contract::AbiProvider>();
}
