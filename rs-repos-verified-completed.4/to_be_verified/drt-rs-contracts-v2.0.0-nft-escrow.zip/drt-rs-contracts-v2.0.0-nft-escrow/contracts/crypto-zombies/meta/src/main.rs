fn main() {
    dharitri_sc_meta::cli_main::<crypto_zombies::AbiProvider>();
}
